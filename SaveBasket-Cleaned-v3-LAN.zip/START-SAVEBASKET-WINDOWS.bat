@echo off
title SaveBasket
echo.
echo ==========================================
echo        SAVEBASKET - EASY START
echo ==========================================
echo.
if not exist node_modules (
  echo Installing SaveBasket for the first time...
  call npm install
  if errorlevel 1 (
    echo.
    echo Node.js/npm could not be found. Please install Node.js 20+ first.
    pause
    exit /b 1
  )
)
if not exist .env (
  echo Creating your private settings file...
  copy /Y .env.example .env >nul
  echo.
  echo IMPORTANT: Open .env and set OWNER_EMAIL and OWNER_PASSWORD.
  echo.
  notepad .env
  echo.
  echo Save the file, then close Notepad.
)
echo Starting SaveBasket...
echo.
echo If you are opening SaveBasket on a phone/tablet, do NOT use localhost.
echo Use your computer LAN address, for example: http://192.168.1.20:3000/owner
echo The server will print the LAN-access instructions below.
timeout /t 2 >nul
call npm start
pause
