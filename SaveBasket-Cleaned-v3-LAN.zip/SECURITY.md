# SaveBasket security & ownership checklist

## Before production
- Change OWNER_PASSWORD and SESSION_SECRET.
- Use HTTPS.
- Use a managed database with encrypted backups for production.
- Put admin behind strong authentication and preferably MFA.
- Do not store raw bank account numbers, sort codes, card data or payment passwords.
- Use Stripe Connect (or another regulated payout provider) for payout onboarding.
- Add CSRF protection if using cookie-authenticated state-changing browser forms beyond this starter.
- Add audit logs for admin actions.
- Add automated backups and restore testing.
- Restrict production database/network access.
- Add privacy policy, terms, cookie consent where required, returns policy and complaints procedure.

## IP protection
Keep dated evidence of:
- first concept and product requirements;
- source code commits;
- design files and brand assets;
- original copy and photography;
- contributor agreements and IP assignments;
- NDAs/confidentiality agreements where appropriate;
- company ownership/share records;
- invoices and investment records.

A copyright notice does not itself protect a business idea. Consider UK trademark registration, appropriate copyright records, contracts/IP assignments and professional legal advice before disclosure to investors or suppliers.
