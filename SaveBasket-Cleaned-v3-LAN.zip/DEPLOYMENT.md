# SaveBasket — production setup checklist

## 1. Local test
- Node.js 20+
- `npm install`
- copy `.env.example` to `.env`
- set `OWNER_EMAIL`, `OWNER_PASSWORD`, and a random `SESSION_SECRET`
- `npm start`
- customer site: `/`
- owner dashboard: `/owner`

## 2. Vercel
Deploy this repository/project to Vercel. Add the environment variables in Vercel Project Settings:
- `NODE_ENV=production`
- `OWNER_EMAIL`
- `OWNER_PASSWORD`
- `SESSION_SECRET`
- `STRIPE_SECRET_KEY` only after Stripe Connect is configured

Important: this starter uses SQLite for local testing. Do not use SQLite as the production database on serverless infrastructure. Replace it with managed Postgres before real customers/orders are handled.

## 3. Stripe Connect
Create/configure a Stripe Connect platform and use account onboarding links. SaveBasket should store only provider account identifiers and payout status, never raw bank account numbers, sort codes, or card numbers.

## 4. Domain
Connect your own SaveBasket domain after the preview deployment passes testing. Enable HTTPS and owner-only admin access.

## 5. Legal/IP
Have a UK solicitor review: Terms of Service, Privacy Notice, Cookies, Returns/Refunds, Complaints procedure, retailer agreements, contractor IP assignment, confidentiality/NDA terms, trademark strategy, and investment/shareholder documents. Copyright notices help evidence ownership but do not prevent copying of an abstract business idea.

## 6. Production hardening
- managed Postgres + backups
- MFA for owner account
- CSRF protection
- audit logs
- monitoring/error alerts
- rate limiting on public support endpoints
- secure secret rotation
- data retention/deletion process
- privacy/data-subject request workflow
- payment webhook verification
- tested refund workflow
