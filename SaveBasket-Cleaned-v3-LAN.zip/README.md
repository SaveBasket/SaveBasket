# SaveBasket Marketplace — Owner/Admin Starter

This build adds a local owner dashboard with:
- secure password hashing and signed HTTP-only session cookie
- orders overview
- complaints management
- returns/refund requests
- retailer management
- dated IP/investment records
- payout placeholder designed around Stripe Connect rather than raw bank details

## Run locally
1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Set environment variables from `.env.example`.
5. Run `npm start`.
6. Open `http://localhost:3000` for the storefront.
7. Open `http://localhost:3000/owner` for owner admin.

The default local credentials are the values in `OWNER_EMAIL` and `OWNER_PASSWORD`; change them before using this outside a private test machine.

## Production
This is a working starter, not a finished audited production system. Move the database to a managed production database, add MFA, CSRF protection, audit logging, monitoring, backups, privacy/terms/returns pages, and a regulated payout provider. Do not store raw banking or card data.


## Phone/tablet access
Do not use `localhost` on your phone when Node is running on your computer. `localhost` refers to the device you're using.
Start SaveBasket on the computer, keep the phone and computer on the same Wi-Fi, find the computer's LAN IPv4 address,
then open `http://YOUR-COMPUTER-IP:3000/owner` on the phone. The server listens on `0.0.0.0` for local-network access.
