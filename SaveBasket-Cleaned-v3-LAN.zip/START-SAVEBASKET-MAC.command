#!/bin/bash
cd "$(dirname "$0")"
echo "=========================================="
echo "        SAVEBASKET - EASY START"
echo "=========================================="
if [ ! -d node_modules ]; then
  echo "Installing SaveBasket for the first time..."
  npm install || { echo "Please install Node.js 20+ first."; read -p "Press Enter"; exit 1; }
fi
if [ ! -f .env ]; then
  cp .env.example .env
  echo "A .env file was created. Open it and set OWNER_EMAIL and OWNER_PASSWORD."
  open -e .env
  read -p "After saving .env, press Enter to continue..."
fi
echo "If you are opening SaveBasket on a phone/tablet, use your Mac\x27s LAN IP instead of localhost."
echo "Example: http://192.168.1.20:3000/owner"
npm start
