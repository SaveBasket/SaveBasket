import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieSession from 'cookie-session';
import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { randomBytes } from 'node:crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database(process.env.DB_PATH || path.join(__dirname,'savebasket.db'));

// Production note: SQLite is suitable for local/private testing only. For a public deployment,
// use a managed Postgres database and set DATABASE_URL; this starter keeps SQLite fallback so
// the project remains runnable locally.
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'owner', must_change_password INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, customer_name TEXT, customer_email TEXT, total_pence INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'new', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS complaints (id INTEGER PRIMARY KEY, order_id INTEGER, customer_email TEXT, subject TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS refunds (id INTEGER PRIMARY KEY, order_id INTEGER, amount_pence INTEGER NOT NULL DEFAULT 0, reason TEXT, status TEXT NOT NULL DEFAULT 'requested', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS retailers (id INTEGER PRIMARY KEY, name TEXT NOT NULL, website TEXT, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS ip_records (id INTEGER PRIMARY KEY, title TEXT NOT NULL, record_type TEXT NOT NULL, notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, metadata TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
`);

const ownerEmail = process.env.OWNER_EMAIL || 'owner@savebasket.local';
const ownerPassword = process.env.OWNER_PASSWORD || 'CHANGE-ME-NOW';
try { db.prepare('ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 1').run(); } catch {}
if (!db.prepare('SELECT 1 FROM users WHERE email=?').get(ownerEmail)) {
  db.prepare('INSERT INTO users(email,password_hash,role,must_change_password) VALUES(?,?,?,1)').run(ownerEmail,bcrypt.hashSync(ownerPassword,12),'owner');
}

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'200kb'}));
app.use(express.urlencoded({extended:false}));
app.use(cookieSession({name:'savebasket_session',keys:[process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex')],httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:1000*60*60*8}));
app.use(express.static(path.join(__dirname,'public')));
const authLimiter=rateLimit({windowMs:15*60*1000,max:20,standardHeaders:true,legacyHeaders:false});

function audit(userId, action, metadata={}) { db.prepare('INSERT INTO audit_log(user_id,action,metadata) VALUES(?,?,?)').run(userId, action, JSON.stringify(metadata)); }

function requireOwner(req,res,next){ if(!req.session?.userId) return res.status(401).json({error:'Owner login required'}); next(); }

app.post('/api/login',authLimiter,(req,res)=>{
  const {email,password}=req.body||{}; const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').trim().toLowerCase());
  if(!u || !bcrypt.compareSync(String(password||''),u.password_hash)) return res.status(401).json({error:'Invalid email or password'});
  req.session.userId=u.id; req.session.role=u.role; req.session.mustChangePassword=!!u.must_change_password; audit(u.id,'login'); res.json({ok:true,mustChangePassword:!!u.must_change_password});
});
app.post('/api/logout',(req,res)=>{if(req.session?.userId) audit(req.session.userId,'logout'); req.session=null;res.json({ok:true})});
app.get('/api/me',requireOwner,(req,res)=>res.json(db.prepare('SELECT id,email,role,created_at,must_change_password FROM users WHERE id=?').get(req.session.userId)));
app.post('/api/change-password',requireOwner,(req,res)=>{
 const {currentPassword,newPassword}=req.body||{};
 const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.session.userId);
 if(!u || !bcrypt.compareSync(String(currentPassword||''),u.password_hash)) return res.status(400).json({error:'Current password is incorrect'});
 if(String(newPassword||'').length < 12) return res.status(400).json({error:'New password must be at least 12 characters'});
 if(String(newPassword) === String(currentPassword)) return res.status(400).json({error:'New password must be different'});
 db.prepare('UPDATE users SET password_hash=?,must_change_password=0 WHERE id=?').run(bcrypt.hashSync(String(newPassword),12),u.id);
 req.session.mustChangePassword=false; audit(u.id,'change_password'); res.json({ok:true});
});
function requireChangedPassword(req,res,next){ if(req.session?.mustChangePassword) return res.status(403).json({error:'Password change required'}); next(); }

app.get('/api/dashboard',requireOwner,requireChangedPassword,(req,res)=>{
 const counts={orders:db.prepare('SELECT COUNT(*) c FROM orders').get().c,complaints:db.prepare("SELECT COUNT(*) c FROM complaints WHERE status!='closed'").get().c,refunds:db.prepare("SELECT COUNT(*) c FROM refunds WHERE status!='completed'").get().c,retailers:db.prepare("SELECT COUNT(*) c FROM retailers WHERE status='active'").get().c};
 res.json({counts,orders:db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 20').all(),complaints:db.prepare('SELECT * FROM complaints ORDER BY id DESC LIMIT 20').all(),refunds:db.prepare('SELECT * FROM refunds ORDER BY id DESC LIMIT 20').all(),retailers:db.prepare('SELECT * FROM retailers ORDER BY id DESC LIMIT 20').all(),ip:db.prepare('SELECT * FROM ip_records ORDER BY id DESC').all()});
});

app.post('/api/complaints', requireOwner, requireChangedPassword, authLimiter, (req,res)=>{const {order_id,customer_email,subject,message}=req.body||{}; if(!subject||!message) return res.status(400).json({error:'Subject and message are required'}); const r=db.prepare('INSERT INTO complaints(order_id,customer_email,subject,message) VALUES(?,?,?,?)').run(order_id||null,customer_email||null,subject,message);res.status(201).json({id:r.lastInsertRowid});});
app.post('/api/refunds', requireOwner, requireChangedPassword, authLimiter, (req,res)=>{const {order_id,amount_pence,reason}=req.body||{}; if(!order_id||!amount_pence) return res.status(400).json({error:'Order and amount are required'}); const r=db.prepare('INSERT INTO refunds(order_id,amount_pence,reason) VALUES(?,?,?)').run(order_id,amount_pence,reason||'');res.status(201).json({id:r.lastInsertRowid,status:'requested'});});
app.post('/api/ip-records',requireOwner,requireChangedPassword,(req,res)=>{const {title,record_type,notes}=req.body||{};if(!title||!record_type)return res.status(400).json({error:'Title and type are required'});const r=db.prepare('INSERT INTO ip_records(title,record_type,notes) VALUES(?,?,?)').run(title,record_type,notes||'');res.status(201).json({id:r.lastInsertRowid});});
app.post('/api/retailers',requireOwner,requireChangedPassword,(req,res)=>{const {name,website}=req.body||{};if(!name)return res.status(400).json({error:'Retailer name is required'});const r=db.prepare('INSERT INTO retailers(name,website) VALUES(?,?)').run(name,website||'');res.status(201).json({id:r.lastInsertRowid});});
app.patch('/api/complaints/:id',requireOwner,requireChangedPassword,(req,res)=>{db.prepare('UPDATE complaints SET status=? WHERE id=?').run(req.body.status,req.params.id);res.json({ok:true})});
app.patch('/api/refunds/:id',requireOwner,requireChangedPassword,(req,res)=>{db.prepare('UPDATE refunds SET status=? WHERE id=?').run(req.body.status,req.params.id);res.json({ok:true})});
app.patch('/api/retailers/:id',requireOwner,requireChangedPassword,(req,res)=>{db.prepare('UPDATE retailers SET status=? WHERE id=?').run(req.body.status,req.params.id);res.json({ok:true})});

app.get('/api/audit',requireOwner,requireChangedPassword,(req,res)=>res.json(db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 100').all()));

app.get('/api/payouts',requireOwner,requireChangedPassword,(req,res)=>res.json({provider:'stripe_connect',status:process.env.STRIPE_SECRET_KEY?'configured_pending_connect_setup':'not_connected',message:'SaveBasket should never store raw bank account numbers or sort codes. Complete Stripe Connect onboarding before accepting live payouts.'}));
app.post('/api/payouts/onboard',requireOwner,requireChangedPassword,(req,res)=>res.json({ok:false,error:'Stripe Connect onboarding still needs to be wired to your connected Stripe account. No bank details are stored by SaveBasket.'}));

app.get('/owner', (req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('/owner/change-password', (req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('/help', (req,res)=>res.sendFile(path.join(__dirname,'public','help.html')));
const port=process.env.PORT||3000;
const host=process.env.HOST||'0.0.0.0';
app.listen(port,host,()=>{
  console.log(`SaveBasket running locally at http://localhost:${port}`);
  console.log(`For another device on the same Wi-Fi, use your computer's LAN IP: http://<YOUR-LAN-IP>:${port}`);
});
