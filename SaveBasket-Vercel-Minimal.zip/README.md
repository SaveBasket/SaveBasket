# SaveBasket — Vercel minimal deployment

Upload this entire folder to Vercel.

Required files:
- package.json
- vercel.json
- api/index.js
- index.html
- owner.html

Set these Vercel Environment Variables before deploying:
- OWNER_EMAIL
- OWNER_PASSWORD
- SESSION_SECRET

Owner page:
`https://YOUR-DOMAIN/owner/change-password`

IMPORTANT: this minimal package is intended to make the Vercel owner page accessible. The Vercel filesystem is not persistent, so a real password change must be stored in a persistent database/managed secret before production use.
